
# coding: utf-8

# In[133]:

# Import modules
import unidecode as ud
import lxml.etree as ET
import pprint as pp
import json
import re

# Import classes
from datetime import datetime
from pymongo import MongoClient

# Global variables

# file for project running, 101Mb
# file_init ="tournefeuille.xml"

# file for project sumbission, 14Mb
file_init ="map.osm"
file_tagok = "tournefeuille_tagok.xml"
file_json = "tournefeuille.json"

result_dict = {}
result_list = []

########################################################################################
# Generic function to parse XML files
# This function will be called for read-only XML parsing using a custom defined function
# This function is an adaptation of Liza Daly's fast_iter function
########################################################################################



def parse(context, func, *args, **kwargs):

    global result_dict
    global result_list
    
    result_dict = {}
    result_list = []
    """
    http://lxml.de/parsing.html#modifying-the-tree
    Based on Liza Daly's fast_iter
    http://www.ibm.com/developerworks/xml/library/x-hiperfparse/
    See also http://effbot.org/zone/element-iterparse.htm
    """
    begin = datetime.now()
    for event, elem in context:
        func(elem, event, *args, **kwargs)
        # It's safe to call clear() here because no descendants will be
        # accessed
        elem.clear()
        # Also eliminate now-empty references from the root node to elem
        for ancestor in elem.xpath('ancestor-or-self::*'):
            while ancestor.getprevious() is not None:
                del ancestor.getparent()[0]
    del context
    
    # Print elapse time
    end = datetime.now()
    print "Start : " + str(begin) + " / Finish : " + str(end) + " / Duration : " + str(end - begin)
    print
    
    # print result dictionnary if not empty  
    if len(result_dict) > 0:
        pp.pprint(result_dict)
    print
    

############################################################
# Generic function used in all various computation performed
#   count   : increase the key counter in a dictionnary
#   isfloat : test is a value is a float
############################################################

def count(keyval, dictionnary):
    if keyval in dictionnary:
        dictionnary[keyval] = dictionnary[keyval] +1
    else:
        dictionnary[keyval] = 1

def isfloat(value):
    try:
        fvalue = float(value)
        return True
    except ValueError:
        return False

print "Init done"


# In[156]:

import os
print "File size (in bytes)"
print os.path.getsize(file_init)


# In[135]:

## structure 1 ## 

# Objective is to get a global view of the XML file content

currentpath = []

def getstructure(elem, event):
    global result_dict
    global currentpath
    
    if event == "start":
        currentpath.append(elem.tag)
        count(' / '.join(currentpath), result_dict)
    else:
        # event = end
        last = currentpath.pop()

    
print "File content - global view"
# look to both start and end event to manage the path stack properly
context = ET.iterparse(file_init, events=('start','end'))
parse(context,getstructure)


# In[136]:

## structure 2 ## 

# Objective is to identify the number of empty and non empty main level 1 tags (node, relation, way)

def countelt(elem, event):
    global result_dict
    
    if len(elem) == 0:
        count('Empty - ' + elem.tag,result_dict)
    else:
        count('Non empty - ' + elem.tag,result_dict)

print "Empty / Non emtpy tags"
# use the end event to be sure children are populated
context = ET.iterparse(file_init, events=('end',),tag=('node','relation','way'))
parse(context,countelt)


# In[137]:

## structure 3 ## 

# Check consistency between the DTD and the real data file content

# The checkvisible global variable is used to activate (or not) the visibility attribute check
checkvisible = True

def checknode(elem, event):
    global result_dict    
    global checkvisible
    
    ok = False
    if elem.tag == "node":
        # check lon and lat belong to the elem and are both float
        if 'lon' in elem.attrib and 'lat' in elem.attrib:
            ok = (isfloat(elem.attrib['lon']) and isfloat(elem.attrib['lat']))
    
    elif elem.tag == "way":    
        
        if checkvisible:
            # we check that the visible tag belong to the element
            if 'visible' in elem.attrib:
                ok = (elem.attrib['visible'] in ['true','false'])
        else:
            ok = True
            
        # we check the element contains at least 2 nd sub elements
        nb = 0
        for subelem in elem:
            if subelem.tag == "nd":
                nb = nb + 1                
        
        # We need at least 2 nd tags to be a valid way
        ok = ok and (nb >= 2)

    else:
        #relation
        if checkvisible:
            # we check that the visible tag belong to the element
            if 'visible' in elem.attrib:            
                ok = (elem.attrib['visible'] in ['true','false'])
        else:
            ok = True
        
        # we check the element contains at least 1 member sub elements
        nb = 0            
        for subelem in elem:
            if subelem.tag == "member":
                nb = nb +1                
        
        # We need at least on member to be valid        
        ok = ok and (nb >= 1)

    key = elem.tag + " - tag " + ("Ok" if ok else "Ko")
    count(key,result_dict)
    
print "Consitency with DTD and associated business rules"    

checkvisible = True
print "Including visibility attribute check"
# use the end event to be sure children are populated
context = ET.iterparse(file_init, events=('end',),tag=('node','way','relation'))
parse(context,checknode)

checkvisible = False
print "Not including visibility attribute check"
# use the end event to be sure children are populated
context = ET.iterparse(file_init, events=('end',),tag=('node','way','relation'))
parse(context,checknode)


# In[138]:

## content 1 ## 

# Check the tags content for the different nodes

def counttag(elem, event):
    global result
    
    for subelem in elem:
        if subelem.tag == "tag":
            count(subelem.attrib['k'],result_dict)

def checktags(xmlfile):
    # use the end event to be sure children are populated
    print "Way tags"
    context = ET.iterparse(xmlfile, events=('end',),tag=('way'))
    parse(context,counttag)

    print "Node tags"
    context = ET.iterparse(xmlfile, events=('end',),tag=('node'))
    parse(context,counttag)

    print "Relation tags"
    context = ET.iterparse(xmlfile, events=('end',),tag=('relation'))
    parse(context,counttag)

print "Check tag content"
checktags(file_init)
    


# In[139]:

##contents 2 ## 

# Delete the tags that do not represent a Map Feature
# The list of tags representing a Map feature has be extracted mannually from : http://wiki.openstreetmap.org/wiki/Map_Features
# We will modify the file content and therefore can not use the iterator based parser we defined.


def deletetag():

    allowedtags = ['abutters','addr:city','addr:conscriptionnumber','addr:country','addr:flats','addr:full','addr:housename','addr:housenumber','addr:inclusion','addr:interpolation','addr:place','addr:postcode','addr:street','admin_level','aerialway','aeroway','amenity','attribution','barrier','bicycle_road','border_type','boundary','bridge','building','building:fireproof','building:levels','busway','comment','craft','cutting','cycleway','description','driving_side','electrified','email','embankment','emergency','entrance','fax','fire_boundary','fixme','ford','frequency','geological','height','highway','historic','ice_road','image','incline','intermittent','is_in','junction','landuse','lanes','leisure','lit','lock','man_made','max_level','military','min_level','mooring','motorroad','mountain_pass','mtb:description','mtb:scale','mtb:scale:imba','mtb:scale:uphill','name','natural','non_existent_levels','note','office','overtaking','parking:condition','parking:lane','passing_places','phone','place','population','postal_code','power','public_transport','railway','railway:track_ref','reference_point','route','sac_scale','seasonal','service','shop','source','source:name','source:ref','source_ref','sport','surface','tactile_paving','todo','tourism','tracks','tracktype','traffic_calming','trail_visibility','tunnel','url','usage','voltage','waterway','website','wikipedia','winter_road']

    tree = ET.parse(file_init)
    root = tree.getroot()
    for tag in root.iter('tag'):
        if not (tag.attrib['k'] in allowedtags):
            tag.getparent().remove(tag)
    
    ET.ElementTree(root).write(file_tagok, xml_declaration=True,encoding="UTF-8")
            
print "Remove non Map Features tags"
deletetag()
print "New file created"
            


# In[140]:

## content 3 ##

# Now check the new generated file tags

checktags(file_tagok)


# In[141]:

## content 4 ## 

# We check the now the tags contents
# These chekcs are defined through function because they will be reused after

def audittag(elem, event):
    global result
    
    count(elem.attrib['k'] + " / " + elem.attrib['v'],result_dict)
    
def checktagcontent():
    # use the end event to be sure children are populated
    context = ET.iterparse(file_tagok, events=('end',),tag=('tag'))
    parse(context,audittag)

print "Check tag content"
checktagcontent()


# In[142]:

## contents 5 ## 

# Transform unicode string to ascci strings

def deleteunicode():

    tree = ET.parse(file_tagok)
    root = tree.getroot()
    for tag in root.iter('tag'):
        if isinstance(tag.attrib['v'], unicode):
            tag.attrib['v'] = ud.unidecode(tag.attrib['v'])
    
    ET.ElementTree(root).write(file_tagok, xml_declaration=True,encoding="UTF-8")
            
print "Remove unicode string"
deleteunicode()
print "New file created"


# In[143]:

## contents 6 ## 

# Recheck content
checktagcontent()


# In[144]:

## contents 7 ## 

## Apply transformation ##

# Transformation to be applied are stored as regular expression within a dictionnary of dictionnary
# The main dictionnary key is the tag on which transformation has to be applied
# The second dictionnary contains the searched pattern (key) and the replacement string (value)

def applymod():

    replace = {
        'addr:city' : { 'COLOMIERS' : 'Colomiers', 'Plaisance-du-Touch' : 'Plaisance du Touch', 'Plaisance du touch' : 'Plaisance du Touch', 'plaisance du touch' : 'Plaisance du Touch' }
        , 'addr:street' : { '\\brue\\b' : 'Rue', '\\ballee\\b' : 'Allee', '\\bavenue\\b' : 'Avenue' , '\\bimpasse\\b' : 'Impasse', '\\bplace\\b' : 'Place' , '\\bAv\\.\\b' : 'Av', '\btouch\b' : 'Touch'}
        , 'addr:postcode' : { '31170 Tournefeuille' : '31170', '31000;31100;31200;31300;31400;31500' : '31000'}
        }

    tree = ET.parse(file_tagok)
    root = tree.getroot()
    for tag in root.iter('tag'):
        if tag.attrib['k'] in replace:
            for mod,value in replace[tag.attrib['k']].iteritems():
                tag.attrib['v'] = re.sub(mod,value,tag.attrib['v'])
        
    
    ET.ElementTree(root).write(file_tagok, xml_declaration=True,encoding="UTF-8")

print "Apply correction"
applymod()
print "New file created"


# In[145]:

## contents 8 ## 

# Recheck content

checktagcontent()


# In[146]:

## contents 9 ## 

## Convert to JSON and store output in a file ##

def encodejson(elem, event):
    global result_list
    
    item = {}
    tag = {}
    member = []
    nd = []
    addr = {}
    
    # Insert a doctype attribute to distinguish between node, ways and relations
    item['doctype'] = elem.tag
    
    # Put attributes stored as text
    for key in ['id','version','changeset','visible','uid','user','timestamp']:
        if key in elem.attrib:
            item[key] = elem.attrib[key]
    
    # Put attributes stored float
    for key in ['lon','lat']:
        if key in elem.attrib:
            item[key] = float(elem.attrib[key])
            
    for subelem in elem:
        if subelem.tag == "tag":
            key = subelem.attrib['k']
            # All addr fields will be stored in a sub element
            if key[:5]== "addr:":
                addr[key[5:]] = subelem.attrib['v']
            else:
                tag[subelem.attrib['k']] = subelem.attrib['v']
                
        elif subelem.tag == "nd":
            # all nd tags will be stored in a dedicated list
            nd.append(subelem.attrib['ref'])
        else:
            # Each member will be stored in a subelement
            onemember = {}
            onemember['type'] = subelem.attrib['type']
            onemember['ref'] = subelem.attrib['ref']
            onemember['role'] = subelem.attrib['role']
            member.append(onemember)            
    
    # Only store sub elements and lists if they contains data
    if len(addr) >0:
        item['addr'] = addr
    if len(tag) > 0:
        item['tag'] = tag
    if len(nd) > 0:
        item['nd'] = nd
    if len(member) > 0:
        item['member'] = member
        
    result_list.append(item)
    count(elem.tag + ' created',result_dict)
       
context = ET.iterparse(file_tagok, events=('end',),tag=('way','node','relation'))
parse(context,encodejson)

# Save json file
with open(file_json, "w") as outfile:    
    json.dump(result_list, outfile, indent=2)


# In[147]:

## contents 10 ## 

## Store data in mongodb ##

client = MongoClient()
db = client.OpenStreetMap
col = db.tournefeuille

# Delete all collection content and insert all result list content
col.delete_many({})
col.insert_many(result_list)
print "Number of document in mongodb"
print db.tournefeuille.count()

# A faster way to import document is to use the mongoimport utility
# mongoimport" --db OpenStreeMap --collection tournefeuille --drop --jsonArray --file tournefeuille.json



# In[148]:

## contents 11 ##

## Perform mongodb query to check data consistency

print "Number of docs per doc type"
aggr = col.aggregate([
        { "$group": { "_id" : "$doctype", "number" : { "$sum" : 1 } } }        
    ])

pp.pprint(list(aggr))
print

print "Number of nodes having an adress"
aggr = col.aggregate([
        { "$match" : { "doctype" : "node", "addr" : { "$exists": 1 }}},
        { "$group": { "_id" : "$doctype", "number" : { "$sum" : 1 } } }        
    ])

pp.pprint(list(aggr))
print

print "Number of nodes having an adress post code but no city"
aggr = col.aggregate([
        { "$match" : { "doctype" : "node", "addr.postcode" : { "$exists": 1 }, "addr.city" : { "$exists": 0 }}},
        { "$group": { "_id" : "$addr.postcode", "number" : { "$sum" : 1 } } }        
    ])

pp.pprint(list(aggr))
print



# In[149]:

## contents 12 ##

# Add city names when missing

col.update_many({ "addr.postcode" : "31170"} , { "$set" : {'addr.city' : 'Tournefeuille'}})
col.update_many({ "addr.postcode" : "31770"} , { "$set" : {'addr.city' : 'Colomiers'}})
col.update_many({ "addr.postcode" : "31830"} , { "$set" : {'addr.city' : 'Plaisance du Touch'}})
col.update_many({ "addr.postcode" : "31100"} , { "$set" : {'addr.city' : 'Toulouse'}})

print "Number of nodes having an adress zip code but no city (should be normally empty)"
aggr = col.aggregate([
        { "$match" : { "doctype" : "node", "addr.postcode" : { "$exists": 1 }, "addr.city" : { "$exists": 0 }}},
        { "$group": { "_id" : "$addr.postcode", "number" : { "$sum" : 1 } } }        
    ])
pp.pprint(list(aggr))


# In[150]:

## contents 13 ##

# Identify for each nodes the number of linked ways and relations

print "Start update"

ways = col.aggregate([
    { "$match" : { "doctype" : "way"}},
    { "$project" : { "uid" : 1 , "nd" : 1}},
    { "$unwind" : "$nd"},
    { "$group" : { "_id" : "$nd", "count" : { "$sum" : 1}}}
    ])

# We won't do one query per node, but one query per number of associated ways
# So we create a list of nodes per ways numbers
groups = {}
for way in ways:
    key = way['count']
    if key in groups:
        group = groups[key]
    else:
        group = []    
    group.append(way['_id'])
    groups[key] = group

# And we now update all related nodes
for key in groups:
    print "Update ways : " + str(key) + " - Number of affected nodes : " + str(len(groups[key]))
    result = col.update_many({ "doctype" : "node", "id" : { "$in" : groups[key]}} , { "$set" : {'linked_ways' : key}})
    pp.pprint("Number of modified document : " + str(result.modified_count))
    
rels = col.aggregate([
    { "$match" : { "doctype" : "relation", "member" : { "$exists" : 1}}},
    { "$project" : { "uid" : 1 , "member" : 1}},
    { "$unwind" : "$member"},
    { "$group" : { "_id" : "$member.ref", "count" : { "$sum" : 1}}}
    ])

# We won't do one query per node, but one query per number of associated relations
# So we create a list of nodes per relations numbers
groups = {}
for rel in rels:
    key = rel['count']
    if key in groups:
        group = groups[key]
    else:
        group = []    
    group.append(rel['_id'])
    groups[key] = group

# And we now update all related nodes
for key in groups:
    print "Update relations : " + str(key) + " - Number of affected nodes : " + str(len(groups[key]))
    result = col.update_many({ "doctype" : "node", "id" : { "$in" : groups[key]}} , { "$set" : {'linked_relations' : key}})
    pp.pprint("Number of modified document : " + str(result.modified_count))
    


# In[151]:

## contents 14 ##

# Get number of nodes not reference at all (no ways, no relations)

nodes = col.aggregate([
    { "$match" : { "doctype" : "node" , "linked_ways" : { "$exists" : 0}, "linked_relations" : { "$exists" : 0}}},
    { "$group" : { "_id" : None, "count" : { "$sum" : 1}}},
    ])

print "Nodes without associateds ways nor relations"
pp.pprint(list(nodes))


# In[152]:

""" contents 15

Additional descriptive statitics

"""
# Top 5 participating users for nodes and associated participation number
# Number of participating users for nodes tags
nodes = col.aggregate([
    { "$match" : { "doctype" : "node"}},
    { "$group" : { "_id" : "$user", "count" : { "$sum" : 1}}},
    { "$sort"  : { "count" : -1}},
    { "$limit" : 5}
    ])

print "Top 5 participating users for nodes tags"
pp.pprint(list(nodes))

# Number of participating users for nodes tags
nodes = col.aggregate([
    { "$match" : { "doctype" : "node"}},
    { "$group" : { "_id" : "$user", "count" : { "$sum" : 1}}},
    { "$group" : { "_id" : None, "count" : { "$sum" : 1 }}}
    ])

print "Number of participating users for node tags"
pp.pprint(list(nodes))
     
# Number of bycicle parking nodes
nodes = col.aggregate([
    { "$match" : { "doctype" : "node", "tag.amenity" : "bicycle_parking"}},
    { "$group" : { "_id" : None, "count" : { "$sum" : 1}}}
    ])

print "Number of bycicle parking nodes"
pp.pprint(list(nodes))

# Number user participating to identify bycicle parking nodes
nodes = col.aggregate([
    { "$match" : { "doctype" : "node", "tag.amenity" : "bicycle_parking"}},
    { "$group" : { "_id" : "$user", "count" : { "$sum" : 1}}},
    { "$group" : { "_id" : None, "count" : { "$sum" : 1}}}
    ])

print "Number of user having participated to identification of bycicle parking nodes"
pp.pprint(list(nodes))

     
     
     


# In[153]:


""" contents 16

Phone number identification

"""

phones = col.find({ "doctype" : "node" , "tag.phone" : { "$exists" : 1}},{ "tag.phone" : 1})
pp.pprint(list(phones))



# In[154]:

## Contents 17 ##

# Phone number correction

phones = list(col.find({ "doctype" : "node" , "tag.phone" : { "$regex" : "\+33 5\d{8}"}},{ "id": 1 , "tag.phone" : 1}))

for phone in phones:
    number = phone['tag']['phone'] 
    number = re.sub('\+33 5(?P<t1>\d{2})(?P<t2>\d{2})(?P<t3>\d{2})(?P<t4>\d{2})','+33 5 \g<t1> \g<t2> \g<t3> \g<t4>', number)
    col.update_one({ "doctype" : "node", "id" : phone['id']} , { "$set" : {'tag.phone' : number}})

phones = list(col.find({ "doctype" : "node" , "tag.phone" : { "$regex" : "0\d{9}"}},{ "id": 1 , "tag.phone" : 1}))

for phone in phones:
    number = phone['tag']['phone']  
    number = re.sub('0(?P<t1>\d{1})(?P<t2>\d{2})(?P<t3>\d{2})(?P<t4>\d{2})(?P<t5>\d{2})','+33 \g<t1> \g<t2> \g<t3> \g<t4> \g<t5>', number)
    col.update_one({ "doctype" : "node", "id" : phone['id']} , { "$set" : {'tag.phone' : number}})
    
phones = list(col.find({ "doctype" : "node" , "tag.phone" : { "$regex" : "0\d( \d{2}){4}"}},{ "id": 1 , "tag.phone" : 1}))

for phone in phones:
    number = phone['tag']['phone']  
    number = re.sub('0(?P<t1>\d{1})(?P<t2> \d{2})(?P<t3> \d{2})(?P<t4> \d{2})(?P<t5> \d{2})','+33 \g<t1>\g<t2>\g<t3>\g<t4>\g<t5>', number)
    col.update_one({ "doctype" : "node", "id" : phone['id']} , { "$set" : {'tag.phone' : number}})

# Check result
phones = col.find({ "doctype" : "node" , "tag.phone" : { "$exists" : 1}},{ "tag.phone" : 1})
pp.pprint(list(phones))


# In[ ]:



